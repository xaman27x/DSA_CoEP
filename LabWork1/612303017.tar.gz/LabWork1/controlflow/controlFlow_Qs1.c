#include <stdio.h>
int main() {
 int i = 3;
 while (i--) {
    int i = 100;
    i--;
    printf("%d ", i);
}
    return 0;
}
