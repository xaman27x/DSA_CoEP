#include <stdio.h>
#include <string.h>

int countOccurencesofChar(char str[], char ch) {
    int len = strlen(str), count = 0;
    for(int i = 0; i < len; i++) {
        if(str[i] == ch) count++;
    };
    return count;
}
