#include <stdio.h>
#include <string.h>

int digitCheck(char p) {
    if(p == '0' || p == '1' || p == '2' || p == '3' || p == '4' || p == '5' || p == '6' || p == '7' || p == '8' || p == '9') {
        return 1;
    };
    return -1;
}

int main() {
    char* digits;
    scanf("%s", digits);
    char* temp = digits;
    int len = strlen(digits);
    for(int i = 0; i < len; i++) {
        if(digitCheck(*temp) != 1) {
            break;
            return 0;
        } else {
            temp++;
            continue;
        }
    }
    temp = digits;
    for(int i = 0; i < len; i++) {
        printf("%d", temp);
    };
    return 0;
}